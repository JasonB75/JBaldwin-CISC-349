Calculator App for CISC 349 Smart Phone Programing project 01
By Jason Baldwin

Similar to the instructor example given in class the operator buttons do not revert color when a number of the second number is selected
    This was done intentionally, because I believe it enhances functionality. Otherwise there is no way to tell which op is selected
    Though this could be changed pretty easily if required.